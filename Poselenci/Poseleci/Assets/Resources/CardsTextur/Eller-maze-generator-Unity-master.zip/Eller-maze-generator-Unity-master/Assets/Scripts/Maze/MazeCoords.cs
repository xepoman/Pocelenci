﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Nox7atra.Mazes
{
    public class MazeCoords
    {
        public MazeCoords(W4Maze maze)
        {
            for(int i = 0; i < maze.ColumnCount; i++)
            {

            }
        }
    }
}